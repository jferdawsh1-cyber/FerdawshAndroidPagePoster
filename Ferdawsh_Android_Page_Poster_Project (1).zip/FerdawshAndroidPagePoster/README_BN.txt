FERDAWSH BULK PAGE POSTER — ANDROID PROJECT

এটি একটি Android Studio project; আগে থেকে তৈরি/সাইন করা APK নয়। এই পরিবেশে APK বিল্ড করা হয়নি।

অ্যাপের সুবিধা:
- Facebook Page ID ও Page Access Token সেট করা
- একাধিক ক্যাপশন/ছবি পোস্ট তালিকায় যোগ করা
- সব পোস্ট প্রকাশের আগে নিশ্চিতকরণ
- টেক্সট পোস্ট / ছবিসহ পোস্ট প্রকাশের চেষ্টা
- Facebook Group-এ সরাসরি পোস্ট করে না; Group-এর জন্য আলাদা অনুমোদিত ব্যবস্থা/ম্যানুয়াল পোস্ট দরকার

APK বানানোর ধাপ (Windows):
1. Android Studio ইনস্টল করুন: https://developer.android.com/studio
2. ZIP ফাইল Extract করুন।
3. Android Studio খুলে Open চাপুন এবং FerdawshAndroidPagePoster ফোল্ডারটি নির্বাচন করুন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন; প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করুন।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. Build সফল হলে app\build\outputs\apk\debug\app-debug.apk ফাইল পাবেন।
7. নিজের Android ফোনে APK কপি করে ইনস্টল করুন। অজানা উৎস থেকে ইনস্টল অনুমতি চাইতে পারে।

Facebook সেটআপ:
- একটি Facebook Page এবং সেই Page-এ পোস্ট করার অনুমতি থাকতে হবে।
- Page ID এবং উপযুক্ত Page Access Token দিন। Token-এ pages_manage_posts অনুমতি প্রয়োজন হতে পারে।
- Meta API সংস্করণ বদলাতে পারে; প্রকাশ ব্যর্থ হলে কোডের MainActivity.kt ফাইলে graphVersion এবং Meta Developer documentation যাচাই করুন।
- Token অ্যাপের local preferences-এ রাখা হয়; production app-এর জন্য encrypted secure storage যোগ করা উচিত। অন্যের সঙ্গে APK/ফোন শেয়ার করবেন না।
- কখনো Page Access Token বা API secret কাউকে পাঠাবেন না।

সীমাবদ্ধতা:
- এই সোর্স প্রজেক্ট পরীক্ষা করে APK বিল্ড করা হয়নি; Android Studio/SDK/Gradle সেটআপে সমস্যা হলে ত্রুটি অনুযায়ী ঠিক করতে হবে।
- Facebook-এর অনুমতি, token মেয়াদ, Page role এবং Meta policy অনুযায়ী পোস্ট ব্যর্থ হতে পারে।
- সর্বোচ্চ পোস্টসংখ্যার অ্যাপ-সাইড সীমা নির্ধারিত নয়; একবারে অল্প পোস্ট দিয়ে পরীক্ষা করুন।
