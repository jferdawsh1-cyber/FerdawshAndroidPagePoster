package com.ferdawsh.pageposter

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.ByteArrayOutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var pageId: EditText
    private lateinit var token: EditText
    private lateinit var caption: EditText
    private lateinit var queueView: LinearLayout
    private lateinit var status: TextView
    private val posts = mutableListOf<Post>()
    private var chosenImage: Uri? = null
    private val prefs by lazy { getSharedPreferences("poster_settings", MODE_PRIVATE) }
    private val graphVersion = "v23.0"
    data class Post(val caption: String, val image: Uri?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 22)
            setBackgroundColor(Color.rgb(248, 249, 250))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        content.addView(label("Ferdawsh Bulk Page Poster", 24, true))
        content.addView(label("Facebook Page-এ একাধিক পোস্ট প্রকাশ করুন", 14, false))
        content.addView(label("Page ID", 16, true))
        pageId = EditText(this).apply { hint = "Facebook Page ID"; setSingleLine(true); setText(prefs.getString("page_id", "")) }
        content.addView(pageId, fullWidth())
        content.addView(label("Page Access Token", 16, true))
        token = EditText(this).apply {
            hint = "এখানে Page Access Token দিন"
            setSingleLine(true)
            inputType = 129
            setText(prefs.getString("page_token", ""))
        }
        content.addView(token, fullWidth())
        content.addView(label("নিরাপত্তা: টোকেন এই ফোনে অ্যাপের সেটিংসে রাখা হয়। ফোন শেয়ার করলে টোকেন সেভ করবেন না।", 12, false))
        content.addView(label("নতুন পোস্ট", 18, true))
        caption = EditText(this).apply { hint = "পোস্টের ক্যাপশন লিখুন"; minLines = 3; gravity = Gravity.TOP; setPadding(14, 12, 14, 12) }
        content.addView(caption, fullWidth())
        val imageButton = Button(this).apply { text = "ছবি নির্বাচন করুন (ঐচ্ছিক)"; setOnClickListener { pickImage() } }
        content.addView(imageButton, fullWidth())
        val addButton = Button(this).apply { text = "পোস্ট তালিকায় যোগ করুন"; setOnClickListener { addPost() } }
        content.addView(addButton, fullWidth())
        content.addView(label("পোস্টের তালিকা", 18, true))
        queueView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(queueView, fullWidth())
        val publishButton = Button(this).apply { text = "সব পোস্ট প্রকাশ করুন"; setOnClickListener { publishAll() } }
        content.addView(publishButton, fullWidth())
        status = label("প্রস্তুত। প্রকাশের আগে Page ID, token ও পোস্ট যাচাই করুন।", 14, false)
        content.addView(status, fullWidth())
    }

    private fun label(text: String, size: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(Color.rgb(35, 45, 55))
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(2, 10, 2, 8)
    }
    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 6 }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        startActivityForResult(intent, 101)
    }
    @Deprecated("Legacy picker callback kept for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            chosenImage = data?.data
            chosenImage?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
            Toast.makeText(this, if (chosenImage != null) "ছবি নির্বাচন করা হয়েছে" else "ছবি নির্বাচন হয়নি", Toast.LENGTH_SHORT).show()
        }
    }
    private fun addPost() {
        val text = caption.text.toString().trim()
        if (text.isEmpty() && chosenImage == null) { Toast.makeText(this, "ক্যাপশন বা ছবি দিন", Toast.LENGTH_SHORT).show(); return }
        posts.add(Post(text, chosenImage))
        caption.setText(""); chosenImage = null
        refreshQueue()
    }
    private fun refreshQueue() {
        queueView.removeAllViews()
        if (posts.isEmpty()) queueView.addView(label("এখনও কোনো পোস্ট যোগ করা হয়নি", 14, false))
        posts.forEachIndexed { i, post ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val summary = TextView(this).apply {
                text = "${i + 1}. ${if (post.caption.isBlank()) "(শুধু ছবি)" else post.caption.take(70)}${if (post.image != null) " [ছবি]" else ""}"
                textSize = 14f; setTextColor(Color.DKGRAY)
            }
            row.addView(summary, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply { text = "বাদ"; setOnClickListener { posts.removeAt(i); refreshQueue() } })
            queueView.addView(row)
        }
    }
    private fun publishAll() {
        val id = pageId.text.toString().trim()
        val accessToken = token.text.toString().trim()
        if (id.isEmpty() || accessToken.isEmpty()) { status.text = "Page ID ও Page Access Token দিন।"; return }
        if (posts.isEmpty()) { status.text = "আগে অন্তত একটি পোস্ট তালিকায় যোগ করুন।"; return }
        AlertDialog.Builder(this).setTitle("পোস্ট প্রকাশ করবেন?")
            .setMessage("${posts.size}টি পোস্ট Facebook Page-এ প্রকাশের চেষ্টা করা হবে। এগিয়ে যাবেন?")
            .setNegativeButton("বাতিল", null).setPositiveButton("প্রকাশ করুন") { _, _ ->
                prefs.edit().putString("page_id", id).putString("page_token", accessToken).apply()
                doPublish(id, accessToken, posts.toList())
            }.show()
    }
    private fun doPublish(id: String, accessToken: String, batch: List<Post>) {
        status.text = "পোস্ট প্রকাশ চলছে... অ্যাপ বন্ধ করবেন না।"
        thread {
            var success = 0; val errors = mutableListOf<String>()
            batch.forEachIndexed { index, post ->
                try {
                    val result = if (post.image != null) publishPhoto(id, accessToken, post) else publishText(id, accessToken, post.caption)
                    if (result.optString("id").isNotEmpty() || result.optString("post_id").isNotEmpty()) success++
                    else errors.add("পোস্ট ${index + 1}: ${result.optJSONObject("error")?.optString("message") ?: "অজানা API উত্তর"}")
                } catch (e: Exception) { errors.add("পোস্ট ${index + 1}: ${e.message ?: "নেটওয়ার্ক সমস্যা"}") }
                runOnUiThread { status.text = "প্রক্রিয়া চলছে: ${index + 1}/${batch.size} · সফল $success" }
            }
            runOnUiThread {
                status.text = "শেষ। সফল: $success/${batch.size}" + if (errors.isNotEmpty()) "\nসমস্যা:\n" + errors.take(5).joinToString("\n") else ""
                if (success == batch.size) { posts.clear(); refreshQueue() }
            }
        }
    }
    private fun publishText(id: String, accessToken: String, message: String): JSONObject {
        val params = "message=${enc(message)}&access_token=${enc(accessToken)}"
        return request("https://graph.facebook.com/$graphVersion/$id/feed", params.toByteArray(Charsets.UTF_8), "application/x-www-form-urlencoded")
    }
    private fun publishPhoto(id: String, accessToken: String, post: Post): JSONObject {
        val uri = post.image!!
        val boundary = "----Ferdawsh${UUID.randomUUID()}"
        val out = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
        }
        field("access_token", accessToken); field("caption", post.caption)
        val mime = contentResolver.getType(uri) ?: "image/jpeg"
        val filename = "upload.${if (mime.contains("png")) "png" else if (mime.contains("gif")) "gif" else "jpg"}"
        out.write("--$boundary\r\nContent-Disposition: form-data; name=\"source\"; filename=\"$filename\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "ছবি ফাইল খোলা যায়নি" }
            val buffer = ByteArray(8192); while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
        }
        out.write("\r\n--$boundary--\r\n".toByteArray())
        return request("https://graph.facebook.com/$graphVersion/$id/photos", out.toByteArray(), "multipart/form-data; boundary=$boundary")
    }
    private fun request(url: String, body: ByteArray, contentType: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 60000
            setRequestProperty("Content-Type", contentType)
        }
        conn.outputStream.use { it.write(body) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        return JSONObject(response)
    }
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
